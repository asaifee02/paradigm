export const items=[
    {
        "name": "Poultry cuts & offal, except livers, fresh or chilled"
    }   
]
